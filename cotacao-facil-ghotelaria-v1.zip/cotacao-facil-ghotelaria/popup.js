const properties = {
  "209202": "Centro Up!",
  "207758": "Pousada Casa Centro",
  "208581": "Centro Class"
};

let currentData = null;
let language = "pt";

const $ = (id) => document.getElementById(id);

function money(cents) {
  return new Intl.NumberFormat("pt-BR", {style:"currency", currency:"BRL"}).format(cents / 100);
}
function parseMoney(text) {
  const match = (text || "").match(/R\$\s*([\d.]+,\d{2})/i);
  if (!match) return null;
  const number = Number(match[1].replace(/\./g, "").replace(",", "."));
  return Number.isFinite(number) ? Math.round(number * 100) : null;
}
function parseISODate(value) {
  const [y,m,d] = value.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d));
}
function formatDate(iso, lang) {
  const date = parseISODate(iso);
  const weekday = new Intl.DateTimeFormat(lang === "es" ? "es" : "pt-BR", {
    weekday:"long", timeZone:"UTC"
  }).format(date);
  return `${weekday.charAt(0).toUpperCase()}${weekday.slice(1)}, ${iso.slice(8,10)}/${iso.slice(5,7)}/${iso.slice(0,4)}`;
}
function daysBetween(start, end) {
  return Math.round((parseISODate(end) - parseISODate(start)) / 86400000);
}
function makeMessage(data, lang) {
  const checkin = formatDate(data.start, lang);
  const checkout = formatDate(data.end, lang);
  const total = money(data.totalCents);
  const deposit = money(Math.round(data.totalCents / 2));
  const remaining = money(data.totalCents - Math.round(data.totalCents / 2));
  if (lang === "es") {
    return `¡Hola! ¿Qué tal? 😊

Te compartimos nuestra cotización para el período solicitado:

🏨 **${data.property}**

📅 **Check-in:** ${checkin}
📅 **Check-out:** ${checkout}
🌙 **Período:** ${data.nights} ${data.nights === 1 ? "noche" : "noches"}

💰 **Valor total del alojamiento: ${total}**

Para garantizar la reserva, solicitamos un pago anticipado del 50% del valor total (${deposit}).

El importe restante de ${remaining} deberá abonarse el día del check-in.

¡Será un placer recibirlos! 🌴`;
  }
  return `Olá! Tudo bem? 😊

Segue nossa cotação para o período solicitado:

🏨 **${data.property}**

📅 **Check-in:** ${checkin}
📅 **Check-out:** ${checkout}
🌙 **Período:** ${data.nights} ${data.nights === 1 ? "diária" : "diárias"}

💰 **Valor total da acomodação: ${total}**

Para garantir a reserva, solicitamos um pagamento antecipado de 50% do valor total (${deposit}).

O valor restante de ${remaining} deverá ser pago no dia do check-in.

Será um prazer receber vocês! 🌴`;
}
function setStatus(message, type="") {
  $("status").textContent = message;
  $("status").className = `status ${type}`;
}
function render() {
  if (!currentData) return;
  $("property").textContent = currentData.property;
  $("checkin").textContent = currentData.start.split("-").reverse().join("/");
  $("checkout").textContent = currentData.end.split("-").reverse().join("/");
  $("nights").textContent = `${currentData.nights}`;
  $("total").textContent = money(currentData.totalCents);
  $("deposit").textContent = money(Math.round(currentData.totalCents / 2));
  $("remaining").textContent = money(currentData.totalCents - Math.round(currentData.totalCents / 2));
  $("message").value = makeMessage(currentData, language);
  $("copy").disabled = false;
}
async function readCloudbeds() {
  setStatus("Lendo a janela de cotação…");
  $("copy").disabled = true;
  try {
    const [tab] = await chrome.tabs.query({active:true, currentWindow:true});
    if (!tab?.id || !tab.url?.startsWith("https://hotels.cloudbeds.com/")) {
      throw new Error("Abra o calendário do Cloudbeds em uma das três propriedades.");
    }
    const results = await chrome.scripting.executeScript({
      target: {tabId:tab.id},
      func: () => {
        const path = location.pathname;
        const id = (path.match(/\/connect\/(\d+)/) || [])[1] || "";
        const visible = (el) => {
          const r = el.getBoundingClientRect();
          const s = getComputedStyle(el);
          return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
        };
        const boxes = [...document.querySelectorAll(".tooltipster-box")].filter(visible);
        const box = boxes.reverse().find(el => el.querySelector(".slot-tt-title") && el.querySelector(".slot-tt-info"));
        if (!box) return {error:"Não encontrei a janela azul. Clique em uma data/valor do calendário para abri-la e tente novamente."};
        const title = box.querySelector(".slot-tt-title")?.innerText?.trim() || "";
        const param = box.querySelector("[data-param]")?.getAttribute("data-param") || "";
        const [start, end] = param.split("|");
        let totalText = "";
        const labels = [...box.querySelectorAll(".slot-tt-info div")];
        const label = labels.find(el => el.children.length === 0 && el.textContent.trim().toLowerCase() === "total da acomodação:");
        if (label?.nextElementSibling) totalText = label.nextElementSibling.textContent.trim();
        if (!totalText) {
          const info = box.querySelector(".slot-tt-info");
          totalText = info?.innerText?.replace(/Total da Acomodação:/i, "").trim() || "";
        }
        const propertyName = document.querySelector(".css-1n4z94z")?.textContent?.trim() || "";
        return {id, title, start, end, totalText, propertyName};
      }
    });
    const found = results?.[0]?.result;
    if (!found || found.error) throw new Error(found?.error || "Não foi possível ler os dados.");
    const property = properties[found.id] || found.propertyName;
    if (!property) throw new Error("Não consegui identificar a pousada.");
    if (!found.start || !found.end || !/^\d{4}-\d{2}-\d{2}$/.test(found.start) || !/^\d{4}-\d{2}-\d{2}$/.test(found.end)) {
      throw new Error("Não encontrei as datas no elemento data-param da janela.");
    }
    const totalCents = parseMoney(found.totalText);
    if (totalCents === null) throw new Error("Não consegui identificar o valor total da acomodação.");
    const nights = daysBetween(found.start, found.end);
    if (nights <= 0) throw new Error("As datas encontradas não formam um período válido.");
    currentData = {property, start:found.start, end:found.end, totalCents, nights};
    render();
    setStatus(`Cotação identificada · ${property}`, "success");
  } catch (error) {
    currentData = null;
    $("property").textContent = "Aguardando leitura";
    $("checkin").textContent = "—";
    $("checkout").textContent = "—";
    $("nights").textContent = "—";
    $("total").textContent = "—";
    $("deposit").textContent = "—";
    $("remaining").textContent = "—";
    $("message").value = "";
    setStatus(error.message || "Ocorreu um erro ao ler o Cloudbeds.", "error");
  }
}
$("refresh").addEventListener("click", readCloudbeds);
$("pt").addEventListener("click", () => {
  language = "pt"; $("pt").classList.add("selected"); $("es").classList.remove("selected");
  if (currentData) render();
});
$("es").addEventListener("click", () => {
  language = "es"; $("es").classList.add("selected"); $("pt").classList.remove("selected");
  if (currentData) render();
});
$("copy").addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText($("message").value);
    setStatus("Cotação copiada! Agora é só colar na conversa.", "success");
  } catch {
    $("message").select();
    document.execCommand("copy");
    setStatus("Cotação copiada! Agora é só colar na conversa.", "success");
  }
});
readCloudbeds();
