const properties = {
  "209202": "Centro Up!",
  "207758": "Pousada Casa Centro",
  "208581": "Centro Class"
};

let currentData = null;
let language = "pt";
let room = 2;
let percent = 50;
const details = {
  "209202": {
    name:"POUSADA CENTRO UP",
    address:"R. Rui Barbosa, 229 A - Lot. Triangulo de Buzios, Armação dos Búzios",
    maps:"https://maps.app.goo.gl/8LPvmBV2XCA1wKNP9",
    photos:"https://photos.app.goo.gl/dpSKEJCMKNFF7jJE7"
  },
  "207758": {
    name:"POUSADA CASA CENTRO",
    address:"R. Rui Barbosa, 390 A - Lot. Triangulo de Buzios, Armação dos Búzios",
    maps:"https://maps.app.goo.gl/guP7PDbX854PmhmZ6",
    photos:"https://photos.app.goo.gl/3JPDo4cmN8kzXSZU6"
  },
  "208581": {
    name:"POUSADA CENTRO CLASS",
    address:"R. Rui Barbosa, 08 - Centro, Armação dos Búzios - RJ",
    maps:"https://maps.app.goo.gl/sF6QJmEnK5qKA7ji8",
    photos:"https://photos.app.goo.gl/HizRbSCCoEL75sqh9"
  }
};
function splitPayment(cents, pct) {
  const deposit = Math.round(cents * pct / 100);
  return {deposit, remaining: cents - deposit};
}

const $ = (id) => document.getElementById(id);

function money(cents) {
  return new Intl.NumberFormat("pt-BR", {style:"currency", currency:"BRL"}).format(cents / 100);
}
function parseMoney(text) {
  const match = (text || "").match(/R\$\s*([\d.]+,\d{2})/i);
  if (!match) return null;
  const number = Number(match[1].replace(/\./g, "").replace(",", "."));
  return Number.isFinite(number) ? Math.round(number * 100) : null;
}
function parseISODate(value) {
  const [y,m,d] = value.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d));
}
function formatDate(iso, lang) {
  const date = parseISODate(iso);
  const weekday = new Intl.DateTimeFormat(lang === "es" ? "es" : "pt-BR", {
    weekday:"short", timeZone:"UTC"
  }).format(date).replace(/\.$/, "");
  return `${weekday.charAt(0).toUpperCase()}${weekday.slice(1)}, ${iso.slice(8,10)}/${iso.slice(5,7)}/${iso.slice(0,4)}`;
}
function daysBetween(start, end) {
  return Math.round((parseISODate(end) - parseISODate(start)) / 86400000);
}
function makeMessage(data, lang, guests=room, pct=percent) {
  const checkin = formatDate(data.start, lang);
  const checkout = formatDate(data.end, lang);
  const total = money(data.totalCents);
  const info = details[data.id];
  const rest = 100 - pct;
  if (lang === "es") {
    return `🏡 ${info.name}
📍 Dirección: ${info.address}
📍 Ubicación: ${info.maps}

🛏️ *${guests === 2 ? "Doble" : "Triple"} Estándar*

📅 *Fechas de la estadía*
➡️ Check-in: ${checkin}
- Horario de check-in: 14 h
⬅️ Check-out: ${checkout}
- Horario de check-out: 12 h

📊 *Resumen de la reserva*
🌙 ${data.nights} ${data.nights === 1 ? "noche" : "noches"}
👥 ${guests} personas
❤️ Desayuno incluido.

💰 *Valor total: ${total}*

⚠️ *Tarifa no reembolsable.*

📷 *Fotos:*
${info.photos}

✅ Para garantizar la reserva, solicitamos el *pago del ${pct}%* vía PIX.

✅ El *${rest}% restante* deberá abonarse al momento del check-in.

🚨 *Importante:*
Esta cotización es válida por 24 horas.
Después de este plazo, será necesario verificar nuevamente la disponibilidad y la tarifa.

¡Te esperamos! 🌟`;
  }
  return `🏡 ${info.name}
📍 Endereço: ${info.address}
📍 Localização: ${info.maps}

🛏️ *${guests === 2 ? "Duplo" : "Triplo"} Standard*

📅 *Datas da Estadia*
➡️ Check-in: ${checkin}
- Check-in: 14h
⬅️ Check-out: ${checkout}
- Check-out: 12h

📊 *Resumo da Reserva*
🌙 ${data.nights} ${data.nights === 1 ? "noite" : "noites"}
👥 ${guests} pessoas
❤️ Café da manhã incluído.

💰 *Valor Total: ${total}*

⚠️ *Tarifa não reembolsável.*

📷 *Imagens:*
${info.photos}

✅ Para garantir a reserva, solicitamos o *pagamento de ${pct}%* via PIX.

✅ Os *${rest}% restantes* deverão ser pagos no momento do check-in.

🚨 *Importante:*
Esta cotação é válida por 24 horas.
Após esse período, será necessário verificar novamente a disponibilidade e a tarifa.

Aguardamos você! 🌟`;
}
function setStatus(message, type="") {
  $("status").textContent = message;
  $("status").className = `status ${type}`;
}
function render() {
  $("depositLabel").textContent = `SINAL (${percent}%)`;
  $("remainingLabel").textContent = `NO CHECK-IN (${100-percent}%)`;
  if (!currentData) return;
  $("property").textContent = currentData.property;
  $("checkin").textContent = currentData.start.split("-").reverse().join("/");
  $("checkout").textContent = currentData.end.split("-").reverse().join("/");
  $("nights").textContent = `${currentData.nights}`;
  $("total").textContent = money(currentData.totalCents);
  const payment = splitPayment(currentData.totalCents, percent);
  $("deposit").textContent = money(payment.deposit);
  $("remaining").textContent = money(payment.remaining);
  $("message").value = makeMessage(currentData, language);
  $("copy").disabled = false;
}
async function readCloudbeds() {
  setStatus("Lendo a janela de cotação…");
  $("copy").disabled = true;
  currentData = null;
  $("message").value = "";
  try {
    const [tab] = await chrome.tabs.query({active:true, currentWindow:true});
    if (!tab?.id || !tab.url?.startsWith("https://hotels.cloudbeds.com/")) {
      throw new Error("Abra o calendário do Cloudbeds em uma das três propriedades.");
    }
    const results = await chrome.scripting.executeScript({
      target: {tabId:tab.id},
      func: () => {
        const path = location.pathname;
        const id = (path.match(/\/connect\/(\d+)/) || [])[1] || "";
        const visible = (el) => {
          const r = el.getBoundingClientRect();
          const s = getComputedStyle(el);
          return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
        };
        const boxes = [...document.querySelectorAll(".tooltipster-box")].filter(visible);
        const box = boxes.reverse().find(el => el.querySelector(".slot-tt-title") && el.querySelector(".slot-tt-info"));
        if (!box) return {error:"Não encontrei a janela azul. Clique em uma data/valor do calendário para abri-la e tente novamente."};
        const title = box.querySelector(".slot-tt-title")?.innerText?.trim() || "";
        const param = box.querySelector("[data-param]")?.getAttribute("data-param") || "";
        const [start, end] = param.split("|");
        let totalText = "";
        const labels = [...box.querySelectorAll(".slot-tt-info div")];
        const label = labels.find(el => el.children.length === 0 && el.textContent.trim().toLowerCase() === "total da acomodação:");
        if (label?.nextElementSibling) totalText = label.nextElementSibling.textContent.trim();
        if (!totalText) {
          const info = box.querySelector(".slot-tt-info");
          totalText = info?.innerText?.replace(/Total da Acomodação:/i, "").trim() || "";
        }
        const propertyName = document.querySelector(".css-1n4z94z")?.textContent?.trim() || "";
        return {id, title, start, end, totalText, propertyName};
      }
    });
    const found = results?.[0]?.result;
    if (!found || found.error) throw new Error(found?.error || "Não foi possível ler os dados.");
    const property = properties[found.id];
    if (!property) throw new Error("Pousada não cadastrada. Abra uma das três propriedades.");
    if (!found.start || !found.end || !/^\d{4}-\d{2}-\d{2}$/.test(found.start) || !/^\d{4}-\d{2}-\d{2}$/.test(found.end)) {
      throw new Error("Não encontrei as datas no elemento data-param da janela.");
    }
    const totalCents = parseMoney(found.totalText);
    if (totalCents === null) throw new Error("Não consegui identificar o valor total da acomodação.");
    const nights = daysBetween(found.start, found.end);
    if (nights <= 0) throw new Error("As datas encontradas não formam um período válido.");
    currentData = {id:found.id, property, start:found.start, end:found.end, totalCents, nights};
    render();
    setStatus(`Cotação identificada · ${property}`, "success");
  } catch (error) {
    currentData = null;
    $("property").textContent = "Aguardando leitura";
    $("checkin").textContent = "—";
    $("checkout").textContent = "—";
    $("nights").textContent = "—";
    $("total").textContent = "—";
    $("deposit").textContent = "—";
    $("remaining").textContent = "—";
    $("message").value = "";
    setStatus(error.message || "Ocorreu um erro ao ler o Cloudbeds.", "error");
  }
}
$("refresh").addEventListener("click", readCloudbeds);
function bindChoice(ids, values, change) {
  ids.forEach((id, index) => $(id).addEventListener("click", () => {
    change(values[index]);
    ids.forEach((other, j) => {
      $(other).classList.toggle("selected", j === index);
      $(other).setAttribute("aria-pressed", String(j === index));
    });
    render();
  }));
}
bindChoice(["pt","es"], ["pt","es"], value => language = value);
bindChoice(["double","triple"], [2,3], value => room = value);
bindChoice(["p50","p30"], [50,30], value => percent = value);
$("copy").addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText($("message").value);
    setStatus("Cotação copiada! Agora é só colar na conversa.", "success");
  } catch {
    $("message").select();
    try {
      if (!document.execCommand("copy")) throw new Error("Falha");
      setStatus("Cotação copiada! Agora é só colar na conversa.", "success");
    } catch {
      setStatus("Não consegui copiar automaticamente. Use Ctrl+C no texto selecionado.", "error");
    }
  }
});
readCloudbeds();
