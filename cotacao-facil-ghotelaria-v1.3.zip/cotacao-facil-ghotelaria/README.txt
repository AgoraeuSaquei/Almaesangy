# Cotação Fácil – GHotelaria (versão inicial)

## Instalação no Chrome
1. Extraia o arquivo ZIP em uma pasta do computador.
2. Abra `chrome://extensions`.
3. Ative **Modo do desenvolvedor**.
4. Clique em **Carregar sem compactação**.
5. Selecione a pasta `cotacao-facil-ghotelaria` que contém `manifest.json`.

## Como usar
1. Entre no calendário clássico do Cloudbeds em uma das propriedades cadastradas.
2. Clique em uma data/valor para abrir a janela azul de cotação.
3. Pressione `Ctrl + Shift + 8` ou clique no ícone da extensão.
4. Confira os dados, escolha Português ou Español e edite a mensagem se desejar.
5. Clique em **Copiar cotação** e cole no WhatsApp.

## Propriedades cadastradas
- Centro Up!: `209202`
- Pousada Casa Centro: `207758`
- Centro Class: `208581`

## Observações
- Esta é uma primeira versão de teste, baseada na estrutura HTML fornecida.
- A extensão só lê os dados visíveis na página aberta; não acessa reservas, hóspedes ou credenciais.
- O atalho pode precisar ser confirmado em `chrome://extensions/shortcuts`, caso o Chrome informe conflito ou não aceite a combinação.
- Se a estrutura do Cloudbeds mudar, os seletores poderão precisar de ajuste.


Atualização 1.3.0
- Selecione Duplo (2 pessoas) ou Triplo (3 pessoas), 50% ou 30% de sinal e idioma.
- A mensagem e os valores do sinal/saldo são recalculados ao clicar.
- A cotação inclui endereço, localização, fotos, café da manhã, tarifa não reembolsável, horários e validade de 24 horas.
- Padrões ao abrir: Duplo, 50%, Português. Seletores regeneram a mensagem (substituem edições manuais).
- A seleção de quarto não muda a tarifa no Cloudbeds. Confira a tarifa correta no calendário.
- Para atualizar a instalação existente, extraia o ZIP, substitua os arquivos dentro da pasta original (mantendo o mesmo caminho), e recarregue em chrome://extensions.
- A mensagem usa asteriscos simples para negrito no WhatsApp.

Versão 1.3: novo ícone GHotelaria no cabeçalho e na barra do Chrome. Funções de cotação preservadas.
