const WINDOW_KEY = "notesWindowId";

async function openNotesWindow() {
  const saved = await chrome.storage.local.get(WINDOW_KEY);
  const existingId = saved[WINDOW_KEY];

  if (existingId !== undefined) {
    try {
      const win = await chrome.windows.get(existingId);
      await chrome.windows.update(win.id, { focused: true });
      return;
    } catch (_) {
      // A janela foi fechada; criaremos outra.
    }
  }

  const win = await chrome.windows.create({
    url: chrome.runtime.getURL("notes.html"),
    type: "popup",
    width: 430,
    height: 620,
    focused: true
  });

  await chrome.storage.local.set({ [WINDOW_KEY]: win.id });
}

chrome.action.onClicked.addListener(openNotesWindow);

chrome.commands.onCommand.addListener((command) => {
  if (command === "open-notes") openNotesWindow();
});

chrome.windows.onRemoved.addListener(async (windowId) => {
  const saved = await chrome.storage.local.get(WINDOW_KEY);
  if (saved[WINDOW_KEY] === windowId) {
    await chrome.storage.local.remove(WINDOW_KEY);
  }
});