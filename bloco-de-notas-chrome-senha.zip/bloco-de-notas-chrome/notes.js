const STORAGE_KEY = "notes";
const PASSWORD_TOKEN = /\/senha:@\[([\s\S]*?)\]@/g;
const $ = (id) => document.getElementById(id);

let notes = [];
let activeId = null;
let saveTimer = null;
let query = "";

function makeId() {
  return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function formatDate(value) {
  if (!value) return "Agora";
  return new Intl.DateTimeFormat("pt-BR", {
    day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit"
  }).format(new Date(value));
}

function currentNote() {
  return notes.find(note => note.id === activeId);
}

async function loadNotes() {
  const data = await chrome.storage.local.get(STORAGE_KEY);
  notes = Array.isArray(data[STORAGE_KEY]) ? data[STORAGE_KEY] : [];
  notes.sort((a, b) => b.updatedAt - a.updatedAt);
  if (notes.length) activeId = notes[0].id;
  render();
}

function scheduleSave() {
  $("saveStatus").textContent = "Salvando...";
  clearTimeout(saveTimer);
  saveTimer = setTimeout(saveNotes, 250);
}

async function saveNotes() {
  try {
    await chrome.storage.local.set({ [STORAGE_KEY]: notes });
    $("saveStatus").textContent = "Todas as alterações salvas";
  } catch (error) {
    $("saveStatus").textContent = "Erro ao salvar";
    console.error(error);
  }
}

function renderList() {
  const list = $("noteList");
  list.replaceChildren();
  const filtered = notes.filter(note => {
    const haystack = `${note.title || ""}\n${note.body || ""}`.toLocaleLowerCase("pt-BR");
    return haystack.includes(query.toLocaleLowerCase("pt-BR"));
  });

  $("noteCount").textContent = String(notes.length);
  $("emptyList").style.display = filtered.length ? "none" : "block";

  for (const note of filtered) {
    const button = document.createElement("button");
    button.className = `note-item${note.id === activeId ? " active" : ""}`;
    button.type = "button";

    const title = document.createElement("strong");
    title.textContent = note.title.trim() || "Sem título";
    const date = document.createElement("small");
    date.textContent = formatDate(note.updatedAt);
    button.append(title, date);
    button.addEventListener("click", () => selectNote(note.id));
    list.append(button);
  }
}

function appendTextWithLineBreaks(parent, text) {
  const parts = text.split("\n");
  parts.forEach((part, index) => {
    if (part) parent.append(document.createTextNode(part));
    if (index < parts.length - 1) parent.append(document.createElement("br"));
  });
}

function createPasswordElement(secret) {
  const wrapper = document.createElement("span");
  wrapper.className = "secret-field";
  wrapper.contentEditable = "false";
  wrapper.dataset.secret = secret;
  wrapper.setAttribute("aria-label", "Senha protegida");

  const mask = document.createElement("span");
  mask.className = "secret-mask";
  mask.textContent = "*******";

  const copyButton = document.createElement("button");
  copyButton.type = "button";
  copyButton.className = "copy-password";
  copyButton.dataset.copyPassword = "true";
  copyButton.textContent = "Copiar";
  copyButton.title = "Copiar senha";
  copyButton.setAttribute("aria-label", "Copiar senha");

  wrapper.append(mask, copyButton);
  return wrapper;
}

function renderBody(body) {
  const editor = $("noteBody");
  editor.replaceChildren();
  PASSWORD_TOKEN.lastIndex = 0;
  let cursor = 0;
  let match;

  while ((match = PASSWORD_TOKEN.exec(body)) !== null) {
    appendTextWithLineBreaks(editor, body.slice(cursor, match.index));
    editor.append(createPasswordElement(match[1]));
    cursor = match.index + match[0].length;
  }

  appendTextWithLineBreaks(editor, body.slice(cursor));
}

function serializeNode(node) {
  if (node.nodeType === Node.TEXT_NODE) return node.nodeValue;
  if (node.nodeType !== Node.ELEMENT_NODE) return "";
  if (node.classList.contains("secret-field")) {
    return `/senha:@[${node.dataset.secret || ""}]@`;
  }
  if (node.tagName === "BR") return "\n";

  const content = Array.from(node.childNodes).map(serializeNode).join("");
  return ["DIV", "P"].includes(node.tagName) ? `${content}\n` : content;
}

function getEditorValue() {
  return Array.from($("noteBody").childNodes).map(serializeNode).join("").replace(/\n$/, "");
}

function renderEditor() {
  const note = currentNote();
  $("editorEmpty").hidden = Boolean(note);
  $("editorContent").hidden = !note;
  if (!note) return;

  $("noteTitle").value = note.title;
  renderBody(note.body || "");
  $("updatedAt").textContent = `Editada: ${formatDate(note.updatedAt)}`;
}

function render() {
  renderList();
  renderEditor();
}

function selectNote(id) {
  activeId = id;
  render();
}

function createNote() {
  const now = Date.now();
  const note = { id: makeId(), title: "", body: "", createdAt: now, updatedAt: now };
  notes.unshift(note);
  activeId = note.id;
  query = "";
  $("search").value = "";
  render();
  $("noteTitle").focus();
  scheduleSave();
}

function updateActiveNote(field, value) {
  const note = currentNote();
  if (!note) return;
  note[field] = value;
  note.updatedAt = Date.now();
  notes.sort((a, b) => b.updatedAt - a.updatedAt);
  $("updatedAt").textContent = `Editada: ${formatDate(note.updatedAt)}`;
  renderList();
  scheduleSave();
}

function deleteActiveNote() {
  const note = currentNote();
  if (!note) return;
  if (!confirm(`Excluir "${note.title.trim() || "Sem título"}"?`)) return;
  notes = notes.filter(item => item.id !== activeId);
  activeId = notes[0]?.id ?? null;
  render();
  scheduleSave();
}

async function copyPassword(button) {
  const secretField = button.closest(".secret-field");
  const secret = secretField?.dataset.secret ?? "";
  try {
    await navigator.clipboard.writeText(secret);
  } catch (_) {
    const helper = document.createElement("textarea");
    helper.value = secret;
    helper.style.position = "fixed";
    helper.style.opacity = "0";
    document.body.append(helper);
    helper.select();
    document.execCommand("copy");
    helper.remove();
  }

  const originalLabel = button.textContent;
  button.textContent = "Copiado!";
  setTimeout(() => { button.textContent = originalLabel; }, 1200);
}

$("newNote").addEventListener("click", createNote);
$("noteTitle").addEventListener("input", event => updateActiveNote("title", event.target.value));
$("noteBody").addEventListener("input", () => {
  const value = getEditorValue();
  updateActiveNote("body", value);

  // Assim que o usuário conclui um token, ele deixa de aparecer em texto aberto.
  if ($("noteBody").textContent.includes("/senha:@[")) {
    renderBody(value);
  }
  PASSWORD_TOKEN.lastIndex = 0;
});
$("noteBody").addEventListener("click", event => {
  const button = event.target.closest("[data-copy-password]");
  if (button) copyPassword(button);
});
$("deleteNote").addEventListener("click", deleteActiveNote);
$("search").addEventListener("input", event => {
  query = event.target.value;
  renderList();
});

document.addEventListener("keydown", event => {
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
    event.preventDefault();
    $("search").focus();
  }
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "n") {
    event.preventDefault();
    createNote();
  }
});

loadNotes();
