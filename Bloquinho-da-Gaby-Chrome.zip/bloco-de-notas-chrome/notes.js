const STORAGE_KEY = "notes";
const PASSWORD_TOKEN = /\/senha:@\[([\s\S]*?)\]@/g;
const HIGHLIGHT_TOKEN = /\uE000HL:([A-Za-z0-9_-]+)\uE001/g;
const $ = (id) => document.getElementById(id);

let notes = [];
let activeId = null;
let saveTimer = null;
let query = "";

function makeId() {
  return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function formatDate(value) {
  if (!value) return "Agora";
  return new Intl.DateTimeFormat("pt-BR", {
    day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit"
  }).format(new Date(value));
}

function toLocalInputValue(timestamp) {
  const local = new Date(timestamp - new Date(timestamp).getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 16);
}

function currentNote() {
  return notes.find(note => note.id === activeId);
}

async function loadNotes() {
  const data = await chrome.storage.local.get(STORAGE_KEY);
  notes = Array.isArray(data[STORAGE_KEY]) ? data[STORAGE_KEY] : [];
  notes.sort((a, b) => b.updatedAt - a.updatedAt);
  const requestedId = new URLSearchParams(location.search).get("note");
  activeId = notes.some(note => note.id === requestedId) ? requestedId : (notes[0]?.id ?? null);
  if (new URLSearchParams(location.search).get("alert") === "1") {
    $("reminderBanner").hidden = false;
  }
  render();
}

function scheduleSave() {
  $("saveStatus").textContent = "Salvando...";
  clearTimeout(saveTimer);
  saveTimer = setTimeout(saveNotes, 250);
}

async function saveNotes() {
  try {
    await chrome.storage.local.set({ [STORAGE_KEY]: notes });
    $("saveStatus").textContent = "Salvo";
  } catch (error) {
    $("saveStatus").textContent = "Erro ao salvar";
    console.error(error);
  }
}

function renderList() {
  const list = $("noteList");
  list.replaceChildren();
  const filtered = notes.filter(note => {
    const readableBody = (note.body || "").replace(/\uE000HL:([A-Za-z0-9_-]+)\uE001/g, (_token, encoded) => decodeHighlight(encoded));
    const haystack = `${note.title || ""}\n${readableBody}`.toLocaleLowerCase("pt-BR");
    return haystack.includes(query.toLocaleLowerCase("pt-BR"));
  });

  $("noteCount").textContent = String(notes.length);
  $("emptyList").style.display = filtered.length ? "none" : "block";

  for (const note of filtered) {
    const button = document.createElement("button");
    button.className = `note-item${note.id === activeId ? " active" : ""}`;
    button.type = "button";
    const title = document.createElement("strong");
    title.textContent = note.title?.trim() || "Sem título";
    const date = document.createElement("small");
    date.textContent = note.reminderAt ? `◷ ${formatDate(note.reminderAt)}` : formatDate(note.updatedAt);
    button.append(title, date);
    button.addEventListener("click", () => selectNote(note.id));
    list.append(button);
  }
}

function appendTextWithLineBreaks(parent, text) {
  const parts = text.split("\n");
  parts.forEach((part, index) => {
    if (part) parent.append(document.createTextNode(part));
    if (index < parts.length - 1) parent.append(document.createElement("br"));
  });
}

function createPasswordElement(secret) {
  const wrapper = document.createElement("span");
  wrapper.className = "secret-field";
  wrapper.contentEditable = "false";
  wrapper.dataset.secret = secret;
  wrapper.setAttribute("aria-label", "Senha protegida");
  const mask = document.createElement("span");
  mask.className = "secret-mask";
  mask.textContent = "*******";
  const copyButton = document.createElement("button");
  copyButton.type = "button";
  copyButton.className = "copy-password";
  copyButton.dataset.copyPassword = "true";
  copyButton.textContent = "Copiar";
  copyButton.title = "Copiar senha";
  copyButton.setAttribute("aria-label", "Copiar senha");
  wrapper.append(mask, copyButton);
  return wrapper;
}

function decodeHighlight(encoded) {
  const base64 = encoded.replace(/-/g, "+").replace(/_/g, "/");
  const binary = atob(base64 + "=".repeat((4 - base64.length % 4) % 4));
  const bytes = Uint8Array.from(binary, character => character.charCodeAt(0));
  return new TextDecoder().decode(bytes);
}

function appendBodyTokens(parent, text) {
  const tokenPattern = /\/senha:@\[([\s\S]*?)\]@|\uE000HL:([A-Za-z0-9_-]+)\uE001/g;
  let cursor = 0;
  let match;
  while ((match = tokenPattern.exec(text)) !== null) {
    appendTextWithLineBreaks(parent, text.slice(cursor, match.index));
    if (match[1] !== undefined) {
      parent.append(createPasswordElement(match[1]));
    } else {
      const highlight = document.createElement("span");
      highlight.className = "highlighted-text";
      appendBodyTokens(highlight, decodeHighlight(match[2]));
      parent.append(highlight);
    }
    cursor = match.index + match[0].length;
  }
  appendTextWithLineBreaks(parent, text.slice(cursor));
}

function renderBody(body) {
  const editor = $("noteBody");
  editor.replaceChildren();
  appendBodyTokens(editor, body || "");
}

function serializeNode(node) {
  if (node.nodeType === Node.TEXT_NODE) return node.nodeValue;
  if (node.nodeType !== Node.ELEMENT_NODE) return "";
  if (node.classList.contains("secret-field")) {
    return `/senha:@[${node.dataset.secret || ""}]@`;
  }
  if (node.classList.contains("highlighted-text")) {
    const value = Array.from(node.childNodes).map(serializeNode).join("");
    const bytes = new TextEncoder().encode(value);
    let binary = "";
    bytes.forEach(byte => { binary += String.fromCharCode(byte); });
    const encoded = btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
    return `\uE000HL:${encoded}\uE001`;
  }
  if (node.tagName === "BR") return "\n";
  const content = Array.from(node.childNodes).map(serializeNode).join("");
  return ["DIV", "P"].includes(node.tagName) ? `${content}\n` : content;
}

function getEditorValue() {
  return Array.from($("noteBody").childNodes).map(serializeNode).join("").replace(/\n$/, "");
}

function renderReminder(note) {
  const input = $("reminderAt");
  const clearButton = $("clearReminder");
  if (note.reminderAt) {
    input.value = toLocalInputValue(note.reminderAt);
    clearButton.hidden = false;
    $("reminderStatus").textContent = `Programado para ${formatDate(note.reminderAt)}.`;
  } else {
    input.value = "";
    clearButton.hidden = true;
    $("reminderStatus").textContent = "Escolha quando o bloquinho deve abrir.";
  }
}

function renderEditor() {
  const note = currentNote();
  $("editorEmpty").hidden = Boolean(note);
  $("editorContent").hidden = !note;
  if (!note) return;
  $("noteTitle").value = note.title || "";
  renderBody(note.body || "");
  $("updatedAt").textContent = note.updatedAt ? `Editada: ${formatDate(note.updatedAt)}` : "Nova nota";
  renderReminder(note);
}

function render() {
  renderList();
  renderEditor();
}

function selectNote(id) {
  activeId = id;
  render();
}

function createNote() {
  const now = Date.now();
  const note = { id: makeId(), title: "", body: "", createdAt: now, updatedAt: now };
  notes.unshift(note);
  activeId = note.id;
  query = "";
  $("search").value = "";
  render();
  $("noteTitle").focus();
  scheduleSave();
}

function updateActiveNote(field, value) {
  const note = currentNote();
  if (!note) return;
  note[field] = value;
  note.updatedAt = Date.now();
  notes.sort((a, b) => b.updatedAt - a.updatedAt);
  $("updatedAt").textContent = `Editada: ${formatDate(note.updatedAt)}`;
  renderList();
  scheduleSave();
}

async function deleteActiveNote() {
  const note = currentNote();
  if (!note) return;
  if (!confirm(`Excluir "${note.title?.trim() || "Sem título"}"?`)) return;
  notes = notes.filter(item => item.id !== activeId);
  if (note.reminderAt) {
    try { await chrome.runtime.sendMessage({ type: "CANCEL_NOTE_REMINDER", noteId: note.id }); } catch (_) { /* nota excluída também remove lembretes obsoletos na inicialização */ }
  }
  activeId = notes[0]?.id ?? null;
  render();
  scheduleSave();
}

async function setReminder() {
  const note = currentNote();
  const value = $("reminderAt").value;
  if (!note) return;
  if (!value) {
    $("reminderStatus").textContent = "Informe a data e a hora do alerta.";
    return;
  }
  const when = new Date(value).getTime();
  if (!Number.isFinite(when) || when <= Date.now()) {
    $("reminderStatus").textContent = "Escolha uma data e hora futuras.";
    return;
  }
  note.reminderAt = when;
  await saveNotes();
  try {
    await chrome.runtime.sendMessage({ type: "SET_NOTE_REMINDER", noteId: note.id, when });
    $("reminderStatus").textContent = `Programado para ${formatDate(when)}. O bloquinho abrirá no horário.`;
    renderList();
    $("clearReminder").hidden = false;
  } catch (error) {
    $("reminderStatus").textContent = "Não foi possível programar. Tente novamente.";
    console.error(error);
  }
}

async function clearReminder() {
  const note = currentNote();
  if (!note) return;
  note.reminderAt = null;
  await saveNotes();
  try { await chrome.runtime.sendMessage({ type: "CANCEL_NOTE_REMINDER", noteId: note.id }); } catch (error) { console.error(error); }
  renderReminder(note);
  renderList();
}

function encodeHighlight(value) {
  const bytes = new TextEncoder().encode(value);
  let binary = "";
  bytes.forEach(byte => { binary += String.fromCharCode(byte); });
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function highlightSelection() {
  const editor = $("noteBody");
  const selection = window.getSelection();
  if (!selection || selection.isCollapsed || !selection.rangeCount) {
    $("saveStatus").textContent = "Selecione um trecho primeiro";
    return;
  }
  const range = selection.getRangeAt(0);
  if (!editor.contains(range.commonAncestorContainer)) {
    $("saveStatus").textContent = "Selecione um trecho da nota";
    return;
  }
  const span = document.createElement("span");
  span.className = "highlighted-text";
  span.append(range.extractContents());
  range.insertNode(span);
  selection.removeAllRanges();
  const note = currentNote();
  if (note) {
    note.body = getEditorValue();
    note.updatedAt = Date.now();
    $("updatedAt").textContent = `Editada: ${formatDate(note.updatedAt)}`;
    renderList();
    scheduleSave();
  }
}

async function copyPassword(button) {
  const secretField = button.closest(".secret-field");
  const secret = secretField?.dataset.secret ?? "";
  try {
    await navigator.clipboard.writeText(secret);
  } catch (_) {
    const helper = document.createElement("textarea");
    helper.value = secret;
    helper.style.position = "fixed";
    helper.style.opacity = "0";
    document.body.append(helper);
    helper.select();
    document.execCommand("copy");
    helper.remove();
  }
  const originalLabel = button.textContent;
  button.textContent = "Copiado!";
  setTimeout(() => { button.textContent = originalLabel; }, 1200);
}

$("newNote").addEventListener("click", createNote);
$("noteTitle").addEventListener("input", event => updateActiveNote("title", event.target.value));
$("noteBody").addEventListener("input", () => {
  const value = getEditorValue();
  updateActiveNote("body", value);
  if ($("noteBody").textContent.includes("/senha:@[")) renderBody(value);
  PASSWORD_TOKEN.lastIndex = 0;
  HIGHLIGHT_TOKEN.lastIndex = 0;
});
$("noteBody").addEventListener("click", event => {
  const button = event.target.closest("[data-copy-password]");
  if (button) copyPassword(button);
});
$("deleteNote").addEventListener("click", deleteActiveNote);
$("setReminder").addEventListener("click", setReminder);
$("clearReminder").addEventListener("click", clearReminder);
$("highlightText").addEventListener("mousedown", event => event.preventDefault());
$("highlightText").addEventListener("click", highlightSelection);
$("search").addEventListener("input", event => {
  query = event.target.value;
  renderList();
});

document.addEventListener("keydown", event => {
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
    event.preventDefault();
    $("search").focus();
  }
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "n") {
    event.preventDefault();
    createNote();
  }
});

loadNotes();
