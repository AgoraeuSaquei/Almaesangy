const WINDOW_KEY = "notesWindowId";
const NOTES_KEY = "notes";
const ALARM_PREFIX = "gaby-note-reminder-";

async function openNotesWindow(noteId = null, isAlert = false) {
  const saved = await chrome.storage.local.get(WINDOW_KEY);
  const existingId = saved[WINDOW_KEY];
  const page = new URL(chrome.runtime.getURL("notes.html"));
  if (noteId) page.searchParams.set("note", noteId);
  if (isAlert) page.searchParams.set("alert", "1");

  // Uma janela de alerta abre diretamente na reserva e não altera a janela de notas já aberta.
  if (!noteId && existingId !== undefined) {
    try {
      const win = await chrome.windows.get(existingId);
      await chrome.windows.update(win.id, { focused: true });
      return;
    } catch (_) {
      // A janela foi fechada; criaremos outra.
    }
  }

  const win = await chrome.windows.create({
    url: page.toString(),
    type: "popup",
    width: 470,
    height: 700,
    focused: true
  });
  // Preserve a referência da janela principal quando um alerta abre uma janela adicional.
  if (existingId === undefined || !noteId) {
    await chrome.storage.local.set({ [WINDOW_KEY]: win.id });
  }
}

function alarmName(noteId) {
  return `${ALARM_PREFIX}${noteId}`;
}

async function setNoteReminder(noteId, when) {
  const data = await chrome.storage.local.get(NOTES_KEY);
  const note = (data[NOTES_KEY] || []).find(item => item.id === noteId);
  if (!note || note.reminderAt !== when || when <= Date.now()) return;
  await chrome.alarms.create(alarmName(noteId), { when });
}

async function cancelNoteReminder(noteId) {
  await chrome.alarms.clear(alarmName(noteId));
}

async function handleReminder(alarm) {
  if (!alarm.name.startsWith(ALARM_PREFIX)) return;
  const noteId = alarm.name.slice(ALARM_PREFIX.length);
  const data = await chrome.storage.local.get(NOTES_KEY);
  const notes = Array.isArray(data[NOTES_KEY]) ? data[NOTES_KEY] : [];
  const note = notes.find(item => item.id === noteId);
  if (!note || !note.reminderAt) return;

  // Ignora qualquer alarme antigo se a data tiver sido alterada.
  if (note.reminderAt > Date.now() + 1000) {
    await chrome.alarms.create(alarmName(noteId), { when: note.reminderAt });
    return;
  }

  note.reminderAt = null;
  await chrome.storage.local.set({ [NOTES_KEY]: notes });
  await openNotesWindow(noteId, true);
  try {
    await chrome.notifications.create(`gaby-alert-${noteId}`, {
      type: "basic",
      iconUrl: "icon-128.png",
      title: "Bloquinho da Gaby",
      message: `Hora de conferir: ${note.title?.trim() || "reserva sem título"}`,
      priority: 2
    });
  } catch (error) {
    console.warn("A janela do bloquinho foi aberta; a notificação do sistema não foi exibida.", error);
  }
}

async function syncReminders() {
  const data = await chrome.storage.local.get(NOTES_KEY);
  const notes = Array.isArray(data[NOTES_KEY]) ? data[NOTES_KEY] : [];
  const active = new Map(notes.filter(note => note.reminderAt).map(note => [alarmName(note.id), note]));
  const existing = await chrome.alarms.getAll();
  for (const alarm of existing) {
    if (alarm.name.startsWith(ALARM_PREFIX) && !active.has(alarm.name)) {
      await chrome.alarms.clear(alarm.name);
    }
  }
  for (const [name, note] of active) {
    if (note.reminderAt <= Date.now()) {
      await handleReminder({ name });
    } else if (!existing.some(alarm => alarm.name === name)) {
      await chrome.alarms.create(name, { when: note.reminderAt });
    }
  }
}

chrome.action.onClicked.addListener(() => openNotesWindow());
chrome.commands.onCommand.addListener(command => {
  if (command === "open-notes") openNotesWindow();
});
chrome.alarms.onAlarm.addListener(handleReminder);
chrome.runtime.onStartup.addListener(syncReminders);
chrome.runtime.onInstalled.addListener(syncReminders);
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  (async () => {
    if (message?.type === "SET_NOTE_REMINDER") {
      await setNoteReminder(message.noteId, message.when);
      sendResponse({ ok: true });
    } else if (message?.type === "CANCEL_NOTE_REMINDER") {
      await cancelNoteReminder(message.noteId);
      sendResponse({ ok: true });
    }
  })().catch(error => sendResponse({ ok: false, error: String(error) }));
  return true;
});
chrome.windows.onRemoved.addListener(async windowId => {
  const saved = await chrome.storage.local.get(WINDOW_KEY);
  if (saved[WINDOW_KEY] === windowId) {
    await chrome.storage.local.remove(WINDOW_KEY);
  }
});
