# Cotação Fácil – GHotelaria (versão 1.1.0)

## Instalação no Chrome
1. Extraia o arquivo ZIP em uma pasta do computador.
2. Abra `chrome://extensions`.
3. Ative **Modo do desenvolvedor**.
4. Clique em **Carregar sem compactação**.
5. Selecione a pasta `cotacao-facil-ghotelaria` que contém `manifest.json`.

Se já tiver a versão anterior instalada, substitua os arquivos da pasta e clique em **Atualizar** na página de extensões do Chrome (ou carregue novamente a pasta).

## Como usar
1. Entre no calendário clássico do Cloudbeds em uma das propriedades cadastradas.
2. Clique em uma data/valor para abrir a janela azul de cotação.
3. Pressione `Ctrl + Shift + 8` ou clique no ícone da extensão.
4. Confira a mensagem em Português ou Español. O texto pode ser editado antes de copiar.
5. Clique em **Copiar cotação** e cole no WhatsApp.

A cotação inclui endereço, link de localização no Google Maps e link de imagens da pousada, além das datas, número de noites, valor total e condições de pagamento. O modelo usa Duplo Standard, 2 pessoas, café da manhã incluído, check-in às 14h, check-out às 12h e tarifa não reembolsável; confira/edite esses detalhes no texto antes de enviar quando a reserva exigir outras condições.

## Propriedades cadastradas
- Centro Up!: `209202`
- Pousada Casa Centro: `207758`
- Centro Class: `208581`

## Observações
- A extensão lê apenas os dados visíveis na página aberta; não acessa reservas, hóspedes ou credenciais.
- Endereços, links de localização e links de imagens estão cadastrados localmente no código da extensão.
- O atalho pode precisar ser confirmado em `chrome://extensions/shortcuts`, caso o Chrome informe conflito ou não aceite a combinação.
- Se a estrutura do Cloudbeds mudar, os seletores poderão precisar de ajuste.
